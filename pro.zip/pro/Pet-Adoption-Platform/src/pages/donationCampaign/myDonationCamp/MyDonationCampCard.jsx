import React from 'react';

const MyDonationCampCard = () => {
    return (
        <div>
            
        </div>
    );
};

export default MyDonationCampCard;