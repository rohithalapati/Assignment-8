
import './App.css'

function App() {
 

  return (
    <>
      <div className='text-3xl bg-red-400 text-center'>
      <h1>React with Tailwind</h1>
      </div>
      
      
      
    </>
  )
}

export default App
